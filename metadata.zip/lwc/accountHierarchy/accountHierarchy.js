import {
    LightningElement,
    track,
    api,
    wire
} from 'lwc';
import { NavigationMixin } from 'lightning/navigation';

import getAccountHierarchyJson from '@salesforce/apex/AccountHierarchyController.getAccountHierarchyJson';
import getColumnsJson from '@salesforce/apex/AccountHierarchyController.getColumnsJson';

export default class AccountHierarchy extends NavigationMixin(LightningElement) {

    @track accountData;
    @track accountDataAll;
    @track columns;
    @track expandedColumns;
    @track isLoading = true;
    @track error;

    @api recordId;

    @wire(getColumnsJson)
    wireColumns({error, data}) {

        this.isLoading = true;

        if (data) {

            this.columns = JSON.parse(data);

            // Set the initialWidth attribute for the Name column
            this.columns.forEach(function (column, index) {
                if (column.fieldName === 'Name') {
                    column.initialWidth = 300;
                }
            });

            this.columns.splice(1, 0, { 
                type: 'button', 
                initialWidth: 100,
                typeAttributes: { 
                    label: 'View', 
                    title: 'View',
                    name: 'view',
                    variant: 'base'
                } 
            });

        } else {
            this.error = error;
        }

        this.isLoading = false;
    }

    @wire(getAccountHierarchyJson,{currentAccountId: '$recordId'})
    wireTreeData({error, data}) {
        
        this.isLoading = true;

        if (data) {
            const tempjson = this.buildJSONStructure(JSON.parse(data));
            this.accountData = [tempjson];

            // Store all Account Data
            this.accountDataAll = [tempjson];
        } else {
            this.error = error;
        }

        this.isLoading = false;
    }

    buildJSONStructure (data) {

        let result = {};
        this.expandedColumns = [];

        for (let key in data) {

            if (Object.prototype.hasOwnProperty.call(data, key)) {

                if (key === 'children') {

                    // Only add to the array if we have child data
                    // Otherwise it's creating an empty arrow
                    if (data.children && data.children.length > 0) {

                        result._children = data.children.map(a => this.buildJSONStructure(a));
                    }
                } 
                else if (key === 'account') {

                    let account = data.account;

                    // If the current row is the page detail Account
                    // Add text to set display
                    if (data.isCurrentAccount) {
                        account.Name = '(Current) ' + account.Name;
                    }

                    // Set object back into the right format
                    result = Object.assign({}, result, account);

                    // Expand all rows
                    this.expandedColumns.push(data.account.Id);
                } 
                else {

                    result[key] = data[key];
                }
            }
        }
        return result;
    }

    // When the View button is clicked
    handleRowAction (event) {
        const action = event.detail.action;
        const row = event.detail.row;

        if (action.name === 'view') {
            this.navigateToViewAccount(row.Id);
        }
    }

    // Navigate to the Account record
    navigateToViewAccount (recordId) {
        this[NavigationMixin.Navigate]({
            type: 'standard__recordPage',
            attributes: {
                recordId: recordId,
                objectApiName: 'Account',
                actionName: 'view'
            },
        });
    }
}